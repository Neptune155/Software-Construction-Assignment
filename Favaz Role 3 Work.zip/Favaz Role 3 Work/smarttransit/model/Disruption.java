/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.smarttransit.model;

/**
 *
 * @author Favaz
 */
/**
 * Represents a disruption affecting a public transport route.
 */
public class Disruption {

    private final String disruptionId;
    private final Route affectedRoute;
    private final String description;
    private final int delayMinutes;
    private boolean active;

    /**
     * Creates a new transport disruption.
     *
     * @param disruptionId unique disruption identifier
     * @param affectedRoute route affected by the disruption
     * @param description explanation of the disruption
     * @param delayMinutes estimated delay in minutes
     */
    public Disruption(String disruptionId, Route affectedRoute,
            String description, int delayMinutes) {

        if (disruptionId == null || disruptionId.isBlank()) {
            throw new IllegalArgumentException(
                    "Disruption ID cannot be empty."
            );
        }

        if (affectedRoute == null) {
            throw new IllegalArgumentException(
                    "Affected route cannot be null."
            );
        }

        if (description == null || description.isBlank()) {
            throw new IllegalArgumentException(
                    "Disruption description cannot be empty."
            );
        }

        if (delayMinutes < 0) {
            throw new IllegalArgumentException(
                    "Delay cannot be negative."
            );
        }

        this.disruptionId = disruptionId;
        this.affectedRoute = affectedRoute;
        this.description = description;
        this.delayMinutes = delayMinutes;
        this.active = true;
    }

    public String getDisruptionId() {
        return disruptionId;
    }

    public Route getAffectedRoute() {
        return affectedRoute;
    }

    public String getDescription() {
        return description;
    }

    public int getDelayMinutes() {
        return delayMinutes;
    }

    public boolean isActive() {
        return active;
    }

    /**
     * Changes the active status of the disruption.
     *
     * @param active whether the disruption is ongoing
     */
    public void setActive(boolean active) {
        this.active = active;
    }
}
