/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.smarttransit.model;

/**
 *
 * @author Favaz
 */
/**
 * Defines the notification behaviour of a subscribed commuter.
 */
public interface CommuterObserver {

    /**
     * Receives an update when a transport disruption occurs.
     *
     * @param disruption information about the disruption
     */
    void update(Disruption disruption);
}
