/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.smarttransit.model;

/**
 *
 * @author Favaz
 */
import java.util.ArrayList;
import java.util.List;

/**
 * Handles journey planning and journey ranking.
 */
public class JourneyPlannerService {

    private final List<Trip> trips;
    private JourneyRankingStrategy rankingStrategy;

    /**
     * Creates a journey planning service.
     *
     * @param trips available transport trips
     * @param rankingStrategy strategy used to rank journeys
     */
    public JourneyPlannerService(
            List<Trip> trips,
            JourneyRankingStrategy rankingStrategy) {

        if (trips == null) {
            throw new IllegalArgumentException(
                    "Trip list cannot be null."
            );
        }

        if (rankingStrategy == null) {
            throw new IllegalArgumentException(
                    "Ranking strategy cannot be null."
            );
        }

        this.trips = new ArrayList<>(trips);
        this.rankingStrategy = rankingStrategy;
    }

    /**
     * Finds direct journey options between two stops.
     *
     * @param origin starting stop
     * @param destination destination stop
     * @return ranked journey options
     */
    public List<JourneyOption> planJourneys(
            Stop origin, Stop destination) {

        if (origin == null || destination == null) {
            throw new IllegalArgumentException(
                    "Origin and destination cannot be null."
            );
        }

        if (origin.equals(destination)) {
            throw new IllegalArgumentException(
                    "Origin and destination must be different."
            );
        }

        List<JourneyOption> journeys = new ArrayList<>();

        for (Trip trip : trips) {
            if (trip.getOrigin().equals(origin)
                    && trip.getDestination().equals(destination)) {
                journeys.add(new JourneyOption(List.of(trip)));
            }
        }

        return rankJourneys(journeys);
    }

    /**
     * Changes the selected journey ranking strategy.
     *
     * @param strategy new ranking strategy
     */
    public void setRankingStrategy(
            JourneyRankingStrategy strategy) {

        if (strategy == null) {
            throw new IllegalArgumentException(
                    "Ranking strategy cannot be null."
            );
        }

        this.rankingStrategy = strategy;
    }

    /**
     * Ranks journey options using the selected strategy.
     *
     * @param journeys journey options to rank
     * @return ranked journey options
     */
    public List<JourneyOption> rankJourneys(
            List<JourneyOption> journeys) {

        if (journeys == null) {
            throw new IllegalArgumentException(
                    "Journey list cannot be null."
            );
        }

        return rankingStrategy.rank(journeys);
    }

    /**
     * Returns the available transport trips.
     *
     * @return unmodifiable list of trips
     */
    public List<Trip> getTrips() {
        return List.copyOf(trips);
    }
}
