/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.smarttransit.model;

/**
 *
 * @author Favaz
 */
import java.util.ArrayList;
import java.util.List;

/**
 * Manages transport disruptions and commuter notifications.
 */
public class DisruptionManager {

    private final List<Disruption> disruptions;
    private final List<CommuterObserver> subscribers;

    /**
     * Creates a disruption manager.
     */
    public DisruptionManager() {
        this.disruptions = new ArrayList<>();
        this.subscribers = new ArrayList<>();
    }

    /**
     * Registers a commuter to receive disruption notifications.
     *
     * @param observer commuter subscribing to alerts
     */
    public void subscribe(CommuterObserver observer) {
        if (observer == null) {
            throw new IllegalArgumentException(
                    "Observer cannot be null."
            );
        }

        if (!subscribers.contains(observer)) {
            subscribers.add(observer);
        }
    }

    /**
     * Removes a commuter from disruption notifications.
     *
     * @param observer commuter unsubscribing from alerts
     */
    public void unsubscribe(CommuterObserver observer) {
        subscribers.remove(observer);
    }

    /**
     * Records a disruption and notifies subscribers.
     *
     * @param disruption disruption to record
     */
    public void recordDisruption(Disruption disruption) {
        if (disruption == null) {
            throw new IllegalArgumentException(
                    "Disruption cannot be null."
            );
        }

        disruptions.add(disruption);
        notifySubscribers(disruption);
    }

    /**
     * Notifies all subscribed commuters about a disruption.
     *
     * @param disruption disruption information to send
     */
    public void notifySubscribers(Disruption disruption) {
        for (CommuterObserver observer :
                new ArrayList<>(subscribers)) {
            observer.update(disruption);
        }
    }

    /**
     * Resolves a disruption using its unique identifier.
     *
     * @param disruptionId identifier of the disruption
     */
    public void resolveDisruption(String disruptionId) {
        for (Disruption disruption : disruptions) {
            if (disruption.getDisruptionId().equals(disruptionId)) {
                disruption.setActive(false);
                return;
            }
        }
    }

    public List<Disruption> getDisruptions() {
        return List.copyOf(disruptions);
    }

    public int getSubscriberCount() {
        return subscribers.size();
    }
}